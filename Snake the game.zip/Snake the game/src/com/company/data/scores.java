package com.company.data;

public class scores {
    public String name;
    public int score;

    public  scores(String name, int score){
        this.name = name;
        this.score = score;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public String toString() {
        final String s = "name=" + name + "\t" +
                "score=" + score;
        return s;
    }
}
